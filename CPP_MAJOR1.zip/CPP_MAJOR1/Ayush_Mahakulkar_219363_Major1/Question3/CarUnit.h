#ifndef CARUNIT_H
#define CARUNIT_H

#include "CarType.h"
#include "CarGearSystemType.h"
#include <iostream>

class CarUnit
{
private:
    /* data */
    std::string m_car_brand;
    float m_car_price;
    CarType m_car_type;
    int m_car_top_speed;
    int m_car_top_rpm;
    CarGearSystem m_car_gear_system;

public:
    CarUnit() = default;                          // disabled default constructor
    CarUnit(const CarUnit &) = delete;            // disabled copy constructor
    CarUnit &operator=(const CarUnit &) = delete; // disabled copy assignment
    CarUnit &operator=(CarUnit &&) = delete;      // enabled move assignment
    CarUnit(CarUnit &&) = delete;                 // disabled move constructor
    ~CarUnit() = default;

    CarUnit(std::string m_car_brand,
            float m_car_price,
            CarType m_car_type,
            int m_car_top_speed,
            int m_car_top_rpm,
            CarGearSystem m_car_gear_system);

    std::string carBrand() const { return m_car_brand; }

    float carPrice() const { return m_car_price; }

    CarType carType() const { return m_car_type; }

    int carTopSpeed() const { return m_car_top_speed; }

    int carTopRpm() const { return m_car_top_rpm; }

    CarGearSystem carGearSystem() const { return m_car_gear_system; }

    friend std::ostream &operator<<(std::ostream &os, const CarUnit &rhs);

    
};

#endif // CARUNIT_H
