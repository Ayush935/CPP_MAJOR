#include "Functionalities.h"

void CreateObjects(MapContainer &data)
{
    data.emplace(std::make_pair<std::string,CarUnitPtr>(
        "101",
        std::make_shared<CarUnit>("AD1",213.9f,CarType::HATCHBACK,12323,300,CarGearSystem::CLASSIC)
    ));

    data.emplace(std::make_pair<std::string,CarUnitPtr>(
        "102",
        std::make_shared<CarUnit>("AD1",213.9f,CarType::SEDAN,12323,300,CarGearSystem::CLASSIC)
    ));

    data.emplace(std::make_pair<std::string,CarUnitPtr>(
        "103",
        std::make_shared<CarUnit>("AD1",213.9f,CarType::SUV,12323,300,CarGearSystem::CLASSIC)
    ));

    data.emplace(std::make_pair<std::string,CarUnitPtr>(
        "104",
        std::make_shared<CarUnit>("AD1",213.9f,CarType::HATCHBACK,12323,300,CarGearSystem::CLASSIC)
    ));

    data.emplace(std::make_pair<std::string,CarUnitPtr>(
        "105",
        std::make_shared<CarUnit>("AD1",213.9f,CarType::HATCHBACK,12323,300,CarGearSystem::CLASSIC)
    ));
    
}

bool CheckAllInstancesHaveSameGearSystem(MapContainer &data)
{
    CarType type = data.begin()->second->carType();

    return std::all_of(
        data.begin(),
        data.end(),
        [&](MapEntry&& ptr){
            return ptr.second->carType()==type;
        }
    );
}

std::optional<Contaioner> InstancesMatchingWithCarType(MapContainer &data, CarType type)
{

    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    Contaioner result;
    std::for_each(
        data.begin(),
        data.end(),
        [&](MapEntry&& ptr){
            if(ptr.second->carType()==type){
                return result.push_back(ptr.second);
            }
        }
    );

    if(result.empty()){
        std::nullopt;
    }

    return result;
}

float CarPriceWithLowestCarTopSpeed(MapContainer &data)
{if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }

    auto itr = std::min_element(
        data.begin(),
        data.end(),
        [](MapEntry&& ptr1, MapEntry&& ptr2){
            return ptr1.second->carTopSpeed()<ptr2.second->carTopSpeed();
        }
    );

    return itr->second->carPrice();
}

int CarTopRpmWhoseIdIsGiven(MapContainer &data, std::string id)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    } 

    auto itr=std::find_if(
        data.begin(),
        data.end(),
        [&](MapEntry&& ptr){
            return ptr.first==id;
        }
    );

    if(itr==data.end()){
        throw InvalidValueException("id does not match");
    }

    return itr->second->carTopRpm();
}

int CountOfInstancesHavingPriceAboveThresold(MapContainer &data,int thresold)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    } 

    int count = std::count_if(
        data.begin(),
        data.end(),
        [&](MapEntry&& ptr){
            return ptr.second->carPrice()>thresold;
        }
    );

    if(count==0){
        throw InvalidValueException("No Instances available");
    }

    return count;
}
