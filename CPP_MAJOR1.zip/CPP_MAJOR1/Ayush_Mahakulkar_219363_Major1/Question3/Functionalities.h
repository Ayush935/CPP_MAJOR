#include "CarUnit.h"
#include <algorithm>
#include <numeric>
#include <optional>
#include "ContainerDataEmptyException.h"
#include <unordered_map>
#include <memory>
#include "InvalidValueException.h"
#include <list>
using CarUnitPtr = std::shared_ptr<CarUnit>;
using MapContainer = std::unordered_map<std::string,CarUnitPtr>;
using MapEntry = std::pair<std::string,CarUnitPtr>;
using Contaioner = std::list<CarUnitPtr>;

/*
  Create 5 Objects in map container
*/
void CreateObjects(MapContainer &data);

/*
  Check If all instances have same Gear System type
*/
bool CheckAllInstancesHaveSameGearSystem(MapContainer &data);

/*
  Return the Container whose instances matches with the Car Type
*/
std::optional<Contaioner> InstancesMatchingWithCarType(MapContainer& data,CarType type);

/*
  Find Car price with the Lowest Car Top speed among instances
*/
float CarPriceWithLowestCarTopSpeed(MapContainer& data);

/*
  Car Top RPM whose ID matches with the given id
*/
int CarTopRpmWhoseIdIsGiven(MapContainer& data, std::string id);

/*
  Count the number of Instances Having Price above THresold
*/
int CountOfInstancesHavingPriceAboveThresold(MapContainer& data,int thresold);



