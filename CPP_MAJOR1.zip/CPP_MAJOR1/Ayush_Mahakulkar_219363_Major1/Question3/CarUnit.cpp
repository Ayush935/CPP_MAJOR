#include "CarUnit.h"
std::ostream &operator<<(std::ostream &os, const CarUnit &rhs) {
    os << "m_car_brand: " << rhs.m_car_brand
       << " m_car_price: " << rhs.m_car_price
       << " m_car_type: " << static_cast<int>(rhs.m_car_type)
       << " m_car_top_speed: " << rhs.m_car_top_speed
       << " m_car_top_rpm: " << rhs.m_car_top_rpm
       << " m_car_gear_system: " << static_cast<int>(rhs.m_car_gear_system);
    return os;
}

CarUnit::CarUnit(std::string m_car_brand, float m_car_price, CarType m_car_type, int m_car_top_speed, int m_car_top_rpm, CarGearSystem m_car_gear_system)
    : m_car_brand{m_car_brand},m_car_price{m_car_price},m_car_type{m_car_type},m_car_top_speed{m_car_top_speed},m_car_top_rpm{m_car_top_rpm},m_car_gear_system{m_car_gear_system}
{
}