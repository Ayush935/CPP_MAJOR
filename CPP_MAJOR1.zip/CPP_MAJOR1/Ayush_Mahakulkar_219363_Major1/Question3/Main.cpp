#include "Functionalities.h"

int main(){
    MapContainer data;
    CreateObjects(data);
    // 
    bool check = CheckAllInstancesHaveSameGearSystem(data);
    std::optional<Contaioner> answer = InstancesMatchingWithCarType(data,CarType::HATCHBACK);
    float CarPrice = CarPriceWithLowestCarTopSpeed(data);
    int CarTopRpm = CarTopRpmWhoseIdIsGiven(data, "101");
    int count = CountOfInstancesHavingPriceAboveThresold(data,200);

    std::cout<<"Container Matching with same type"<<std::endl;
    if(answer.has_value()){
        Contaioner res = answer.value();
        for(CarUnitPtr ptr: res){
            std::cout<<*ptr<<std::endl;
        }
    }
    std::cout<<"All Instances have Same Gear Type"<<std::boolalpha<<check<<std::endl;
    std::cout<<"Car Price having lowest Speed "<<CarPrice<<std::endl;
    std::cout<<"Cars Top Rpm whose id is given "<<CarTopRpm<<std::endl;
    std::cout<<"Count of Instances having Price above Thresold "<<count<<std::endl;
   

}