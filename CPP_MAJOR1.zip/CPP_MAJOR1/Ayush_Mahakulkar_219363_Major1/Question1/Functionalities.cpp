#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.emplace_back(std::make_shared<EvCar>("Mh123",25,EvCarType::IC_BASED,23.4f,23,345));
    data.emplace_back(std::make_shared<EvCar>("Mh124",30,EvCarType::PURE_EV,26.4f,43,390));
    data.emplace_back(std::make_shared<EvCar>("Mh125",40,EvCarType::IC_BASED,53.4f,33,385));
    data.emplace_back(std::make_shared<EvCar>("Mh126",50,EvCarType::PURE_EV,27.4f,33,350));
    data.emplace_back(std::make_shared<EvCar>("Mh127",60,EvCarType::IC_BASED,83.4f,53,345));
}

std::optional<LContainer> FindFirstNinstances(const Container &data, unsigned int N)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    
    if(N<0 || N>data.size()){
        throw InvalidValueException("Value is invalid");
    }
    LContainer result;
    std::copy_n(
        data.begin(),
        N,
        std::inserter(result,result.begin())
    );

    if(result.empty()){
        std::nullopt;
    }

    return result;
}

int CountOfInstancesChassisLengthAboveGivenData(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    
    int count = std::count_if(
        data.begin(),
        data.end(),
        [](const EvCarPtr &ptr){
             return ptr->chassisLength()>2.7f;
        }
    );

    if(count == 0){
        throw InvalidValueException("No such instances found");
    }

    return count;
}

int TopSpeedWhoseIdMatchesWithtTheParameter(const Container &data, std::string id)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }

    auto itr = std::find_if(
        data.begin(),
        data.end(),
        [&](const EvCarPtr& ptr){
            return ptr->carId()==id;
        }
    );

    if(itr==data.end()){
         throw InvalidValueException("No such instances found");
    }

    return (*itr)->topSpeed();
}

std::optional<Container> InstancesSatisfiesTheGivenPredicate(const Container &data, std::function<bool(int)>fn)
{
  if(data.empty()){
        throw ContainerEmptyException("Data is empty");
  }

  Container result;
  std::for_each(
    data.begin(),
    data.end(),
    [&](const EvCarPtr& ptr){
         if(fn(ptr->topSpeed())){
            return result.push_back(ptr);
         }
    }
  );

  if(result.empty()){
      std::nullopt;
  }

  return result;

}

bool IsAnyInstancesHaveSameEvCarType(const Container &data)
{
  if(data.empty()){
        throw ContainerEmptyException("Data is empty");
  }

  return std::any_of(
    data.begin(),
    data.end(),
    [](const EvCarPtr& ptr){
        return ptr->platform()==EvCarType::PURE_EV;
    }
  );
}
