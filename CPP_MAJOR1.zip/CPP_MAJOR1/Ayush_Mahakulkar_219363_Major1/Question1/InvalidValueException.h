#ifndef INVALIDVALUEEXCEPTION_H
#define INVALIDVALUEEXCEPTION_H

#include <stdexcept>

class InvalidValueException : std::exception
{
private:
    std::string _msg;

public:
    InvalidValueException(std::string msg) : _msg(msg) {}
    InvalidValueException() = default;                                          // disabled default constructor
    InvalidValueException(const InvalidValueException &) = delete;            // disabled copy constructor
    InvalidValueException &operator=(const InvalidValueException &) = delete; // disabled copy assignment
    InvalidValueException &operator=(InvalidValueException &&) = default;     // enabled move assignment
    InvalidValueException(InvalidValueException &&) = delete;                 // disabled move constructor
    ~InvalidValueException() = default;                                         // disabled default destructor
    std::string what() { return _msg; }                                           // getter for _msg!
};


#endif // INVALIDVALUEEXCEPTION_H
