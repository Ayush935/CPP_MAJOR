#include "EvCar.h"
std::ostream &operator<<(std::ostream &os, const EvCar &rhs) {
    std::string val = " ";
    if(rhs.m_platform==EvCarType::IC_BASED){
        val = "IC_BASED";
    }
    else{
        val = "PURE_EV";
    }
    os << "m_car_id: " << rhs.m_car_id
       << " m_battery_charging_time: " << rhs.m_battery_charging_time
       << " m_platform: " << val
       << " m_chassis_length: " << rhs.m_chassis_length
       << " m_seat_count: " << rhs.m_seat_count
       << " m_top_speed: " << rhs.m_top_speed;
    return os;
}

EvCar::EvCar(std::string _car_id, int _battery_charging_time, EvCarType _platform, float _chassis_length, int _seat_count, int _top_speed)
    : m_car_id{_car_id},m_battery_charging_time{_battery_charging_time},m_platform{_platform},m_chassis_length{_chassis_length},m_top_speed{_top_speed}
{
}