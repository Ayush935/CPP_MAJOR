#ifndef EVCAR_H
#define EVCAR_H

#include <iostream>
#include "EvCarType.h"

class EvCar
{
private:
    /* data */
    std::string m_car_id;
    int m_battery_charging_time;
    EvCarType m_platform;
    float m_chassis_length;
    int m_seat_count;
    int m_top_speed;

public:
    EvCar() = default;                        // disabled default constructor
    EvCar(const EvCar &) = delete;            // disabled copy constructor
    EvCar &operator=(const EvCar &) = delete; // disabled copy assignment
    EvCar &operator=(EvCar &&) = delete;      // enabled move assignment
    EvCar(EvCar &&) = delete;                 // disabled move constructor
    ~EvCar() = default;

    EvCar(std::string _car_id,
          int _battery_charging_time,
          EvCarType _platform,
          float _chassis_length,
          int _seat_count,
          int _top_speed);

    std::string carId() const { return m_car_id; }

    int batteryChargingTime() const { return m_battery_charging_time; }

    EvCarType platform() const { return m_platform; }

    float chassisLength() const { return m_chassis_length; }

    int seatCount() const { return m_seat_count; }

    int topSpeed() const { return m_top_speed; }

    friend std::ostream &operator<<(std::ostream &os, const EvCar &rhs);

          
};

#endif // EVCAR_H
