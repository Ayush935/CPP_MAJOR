#include "Functionalities.h"

int main(){
    Container data;
    CreateObjects(data);

    try
    {
        /* code */
        std::optional<LContainer> result = FindFirstNinstances(data,3);
        int count = CountOfInstancesChassisLengthAboveGivenData(data);
        int ans = TopSpeedWhoseIdMatchesWithtTheParameter(data,"Mh123");
        std::optional<Container> result1 = InstancesSatisfiesTheGivenPredicate(data, [](int num){return num>300;});
        bool check = IsAnyInstancesHaveSameEvCarType(data);
        
        std::cout<<"Any one of the instance having same type that of PUREEV "<<std::boolalpha<<check<<std::endl;
        std::cout<<"Top Speed whose Id matches with given id "<<ans<<std::endl;
        std::cout<<"Count of Instances whose lengh is above 2.7 are "<<count<<std::endl;
        std::cout<<"First N instances are"<<std::endl;
        if(result.has_value()){
            LContainer answer = result.value();
            for(EvCarPtr ptr: answer){
                std::cout<<*ptr<<std::endl;
            }
        }
        else{
            std::cout<<"There are no such instances"<<std::endl;
        }
        
        std::cout<<"Instances Satisfy the given Predicate"<<std::endl;
        if(result1.has_value()){
           Container res1 = result1.value();
           for(EvCarPtr ptr: res1){
                std::cout<<*ptr<<std::endl;
            }

        }
        else{
            std::cout<<"No such instances"<<std::endl;
        }
    }
    catch(ContainerEmptyException& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}