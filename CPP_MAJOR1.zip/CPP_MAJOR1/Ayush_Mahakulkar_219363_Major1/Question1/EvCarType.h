#ifndef EVCARTYPE_H
#define EVCARTYPE_H

enum class EvCarType
{
    PURE_EV,
    IC_BASED
};

#endif // EVCARTYPE_H
