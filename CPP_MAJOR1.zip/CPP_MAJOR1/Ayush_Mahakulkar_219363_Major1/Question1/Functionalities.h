#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "EvCar.h"
#include <list>
#include <memory>
#include <vector>
#include "ContainerEmptyDataException.h"
#include "InvalidValueException.h"
#include <functional>
#include <optional>
#include <algorithm>
#include <numeric>
using EvCarPtr = std::shared_ptr<EvCar>;
using Container = std::vector<EvCarPtr>;
using LContainer = std::list<EvCarPtr>;


/*
  Create 5 instances of datas
*/
void CreateObjects(Container& data);

/*
  return list of first N instances from the parameter
*/
std::optional<LContainer> FindFirstNinstances(const Container&data, unsigned int N);

/*
  Find and return count of instances have chassis length above 2.7f
*/
int CountOfInstancesChassisLengthAboveGivenData(const Container& data);

/*
  Return Top Speed of EvCar whose CarId is given
*/
int TopSpeedWhoseIdMatchesWithtTheParameter(const Container&data, std::string id);

/*
  Return a container which satisfies the predicate
*/
std::optional<Container>  InstancesSatisfiesTheGivenPredicate(const Container& data, std::function<bool(int)>);

/*
  Return Boolean to indicate whether at leat one input data instance has m_platform value as PURE_EV
*/
bool IsAnyInstancesHaveSameEvCarType(const Container& data);

#endif // FUNCTIONALITIES_H
