#include "ICECar.h"
std::ostream &operator<<(std::ostream &os, const ICECar &rhs) {
    os << "_id: " << rhs._id
       << " _brand_name: " << rhs._brand_name
       << " _price: " << rhs._price
       << " _engine_type: " << static_cast<int>(rhs._engine_type);
    return os;
}

ICECar::ICECar(std::string _id, std::string _brand_name, float _price, EngineType _engine_type)
    : _id{_id},_price{_price},_engine_type{_engine_type}
{
}

float ICECar::CalculateRegistrationCharges()
{
    if(EngineType::DIESEL==_engine_type){
        return 0.13*_price;
    }

    return 0.10*_price;
}
