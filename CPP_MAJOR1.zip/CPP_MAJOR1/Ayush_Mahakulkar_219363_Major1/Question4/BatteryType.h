#ifndef BATTERYTYPE_H
#define BATTERYTYPE_H

enum class BatteryType{
    LI_ON,
    NICAD,
    OTHER
};

#endif // BATTERYTYPE_H
