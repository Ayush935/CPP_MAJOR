#ifndef ICECAR_H
#define ICECAR_H

#include "EngineType.h"
#include <iostream>

class ICECar
{
private:
    /* data */
    std::string _id;
    std::string _brand_name;
    float _price;
    EngineType _engine_type;

public:
    ICECar() = default;                         // disabled default constructor
    ICECar(const ICECar &) = delete;            // disabled copy constructor
    ICECar &operator=(const ICECar &) = delete; // disabled copy assignment
    ICECar &operator=(ICECar &&) = default;     // enabled move assignment
    ICECar(ICECar &&) = delete;                 // disabled move constructor
    ~ICECar() = default;

    ICECar(std::string _id,
           std::string _brand_name,
           float _price,
           EngineType _engine_type);

    float CalculateRegistrationCharges();

    std::string id() const { return _id; }

    std::string brandName() const { return _brand_name; }
    void setBrandName(const std::string &brand_name) { _brand_name = brand_name; }

    float price() const { return _price; }

    EngineType engineType() const { return _engine_type; }

    friend std::ostream &operator<<(std::ostream &os, const ICECar &rhs);
};

#endif // ICECAR_H
