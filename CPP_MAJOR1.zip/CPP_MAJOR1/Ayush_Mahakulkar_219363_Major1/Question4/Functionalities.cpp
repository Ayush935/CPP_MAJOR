#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.emplace_back(std::make_shared<ICECar>("MH123","ABC",900000.0F,EngineType::DIESEL));
    data.emplace_back(std::make_shared<ICECar>("MH124","ABCD",400000.0F,EngineType::PETROL));
    data.emplace_back(std::make_shared<EvCar>("MH125","FGH",400000.0f,EPowerType::ELECTRIC,BatteryType::LI_ON));
    data.emplace_back(std::make_shared<EvCar>("MH126","KFGH",4000.0f,EPowerType::HYBRID,BatteryType::NICAD));
    data.emplace_back(std::make_shared<EvCar>("MH127","FGHI",1400000.0f,EPowerType::ELECTRIC,BatteryType::OTHER));
}

Container InstancesHavingPriceBelow600000(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }

    Container result;
    float price{0.0f};
    for(const VType& v: data){
        std::visit(
            [&](auto &&val){
                price = val->price();
            },v
        );
        if(price<600000){
            result.push_back(v);
        }
    }

    if(result.empty()){
        throw ContainerEmptyException("Data is Empty");
    }

    return result;
}

float AveragePriceForEvCars(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    
    float sum{0.0f};
    int count{0};
    for(const VType &v: data){
        if(std::holds_alternative<EvCarPtr>(v)){
            sum+=std::get<EvCarPtr>(v)->price();
            count++;
        }
        
    }

    return sum/static_cast<float>(count);
}

int CountEvCarHavingSameEPowerType(const Container &data, EPowerType type)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }

    int count{0};
    for(const VType &v: data){
        if(std::holds_alternative<EvCarPtr>(v)){
            if(std::get<EvCarPtr>(v)->engineType()==type){
               count++;
            }
            
        }
        
    }

    if(count==0){
        throw;
    }

    return count;
}

std::string BrandNameWhichMatchesWithId(const Container &data, std::string id)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }

    std::string Brand = "";
    
    bool flag{false};
    for(const VType& v: data){
        std::visit(
            [&](auto &&val){
                if(val->id()==id){
                    Brand = val->brandName();
                    flag=true;
                }
            },v
        ); 
        if(flag){
            break;
        }
    }

    if(!flag){
        throw;
    }

    return Brand;
}

SetContainer FindAndReturnUniqueBatteryType(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    SetContainer result;
     for(const VType &v: data){
        if(std::holds_alternative<EvCarPtr>(v)){
            result.insert(std::get<EvCarPtr>(v)->batteryType());
            
        }
        
    }

    if(result.empty()){
        throw;
    }

    return result;
}

bool IsAnyOneInstanceHavePriceAbove60000(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty");
    }
    float price{0.0f};
    int count{0};
     for(const VType& v: data){
        std::visit(
            [&](auto &&val){
                price = val->price();
            },v
        );
        if(price>600000){
            count++;
        }
    }
    if(count==0){
        return false;
    }
    return true;
}
