#ifndef EPOWERTYPE_H
#define EPOWERTYPE_H

enum class EPowerType{
    HYBRID,
    ELECTRIC
};

#endif // EPOWERTYPE_H
