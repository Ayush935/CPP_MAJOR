#include "Functionalities.h"

int main(){
    Container data;
    CreateObjects(data);

    Container result = InstancesHavingPriceBelow600000(data);
    float Average = AveragePriceForEvCars(data);
    int count = CountEvCarHavingSameEPowerType(data, EPowerType::ELECTRIC);
    std::string brand = BrandNameWhichMatchesWithId(data,"MH123");
    SetContainer result1 = FindAndReturnUniqueBatteryType(data);
    bool check = IsAnyOneInstanceHavePriceAbove60000(data);
    
    std::cout<<"Brand Name Having same id "<<brand<<std::endl;
    std::cout<<"Intances Having Price Below 600000"<<std::endl;
    for(VType &v: result){
        if(std::holds_alternative<EvCarPtr>(v)){
            std::cout<<*(std::get<EvCarPtr>(v))<<"\n";
        }
        else if(std::holds_alternative<ICECarPtr>(v)){
            std::cout<<*(std::get<ICECarPtr>(v))<<"\n";
        }
    }
   
    std::cout<<"Average of EV Car Prices is "<<Average<<std::endl;
    std::cout<<"Count of EvCar Having Same EPower Type "<<count<<std::endl;
    std::cout<<"Unique Battery Type "<<" ";

    for(BatteryType vt:result1){
        if(vt==BatteryType::LI_ON){
            std::cout<<"LI_ON"<<" ";
        }
        else if(vt==BatteryType::NICAD){
            std::cout<<"NICAD"<<" ";
        }
        else{
            std::cout<<"OTHER"<<" ";
        }
    }
    std::cout<<std::endl;

    std::cout<<"Is there Any instance with price above 60000 "<<std::boolalpha<<check;
}