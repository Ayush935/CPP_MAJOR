#include "EvCar.h"
std::ostream &operator<<(std::ostream &os, const EvCar &rhs) {
    os << "_id: " << rhs._id
       << " _brand_name: " << rhs._brand_name
       << " _price: " << rhs._price
       << " _engine_type: " << static_cast<int>(rhs._engine_type)
       << " _battery_type: " << static_cast<int>(rhs._battery_type);
    return os;
}

EvCar::EvCar(std::string _id, std::string _brand_name, float _price, EPowerType _engine_type, BatteryType _battery_type)
    : _id{_id},_brand_name{_brand_name},_price{_price},_engine_type{_engine_type},_battery_type{_battery_type}
{
}

float EvCar::CalculateRegistrationCharges()
{
    if(EPowerType::ELECTRIC==_engine_type){
        return 0.05*_price;
    }
    return 0.08*_price;
}
