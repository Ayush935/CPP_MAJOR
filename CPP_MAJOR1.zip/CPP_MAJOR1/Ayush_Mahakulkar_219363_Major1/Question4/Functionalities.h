#include "EvCar.h"
#include "ICECar.h"
#include <variant>
#include <memory>
#include <vector>
#include <unordered_set>
#include "ContainerEmptyDataException.h"
using EvCarPtr = std::shared_ptr<EvCar>;
using ICECarPtr = std::shared_ptr<ICECar>;
using VType = std::variant<EvCarPtr,ICECarPtr>;
using Container = std::vector<VType>;
using SetContainer = std::unordered_set<BatteryType>;

/*
  Create Objects using variant of EvCar and ICCeCar
*/
void CreateObjects(Container& data);

/*
  FIND Instances Having Price Below 600000
*/
Container InstancesHavingPriceBelow600000(const Container& data);

/*
  FIND Average PriceFor EvCars
*/
float AveragePriceForEvCars(const Container& data);

/*
  fIND The Count of EvCar Having SameEPowerType
*/
int CountEvCarHavingSameEPowerType(const Container& data,EPowerType type);

/*
  Find Brand Name Which Matches With Id
*/
std::string BrandNameWhichMatchesWithId(const Container& data,std::string id);

/*
  Find Unique Battery Type
*/
SetContainer FindAndReturnUniqueBatteryType(const Container& data);

/*
  Is Any One of Instance Have Price Above 60000
*/
bool IsAnyOneInstanceHavePriceAbove60000(const Container& data);