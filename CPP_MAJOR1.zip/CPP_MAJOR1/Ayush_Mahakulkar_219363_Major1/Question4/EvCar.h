#ifndef EVCAR_H
#define EVCAR_H

#include <iostream>
#include "BatteryType.h"
#include "EPowerType.h"
class EvCar
{
private:
    /* data */
    std::string _id;
    std::string _brand_name;
    float _price;
    EPowerType _engine_type;
    BatteryType _battery_type;
public:
    EvCar() = default;                        // disabled default constructor
    EvCar(const EvCar &) = delete;            // disabled copy constructor
    EvCar &operator=(const EvCar &) = delete; // disabled copy assignment
    EvCar &operator=(EvCar &&) = default;     // enabled move assignment
    EvCar(EvCar &&) = delete;                 // disabled move constructor
    ~EvCar() = default;

    EvCar(std::string _id,
    std::string _brand_name,
    float _price,
    EPowerType _engine_type,
    BatteryType _battery_type);
    
    float CalculateRegistrationCharges();

    std::string id() const { return _id; }

    std::string brandName() const { return _brand_name; }

    float price() const { return _price; }

    EPowerType engineType() const { return _engine_type; }

    BatteryType batteryType() const { return _battery_type; }

    friend std::ostream &operator<<(std::ostream &os, const EvCar &rhs);

};

#endif // EVCAR_H
