#ifndef CAR_H
#define CAR_H

#include "Engine.h"
#include <functional>
#include <ostream>
using EngineRef = std::reference_wrapper<Engine>;

class Car
{
private:
    /* data */
    std::string m_car_reg_num;
    float m_price;
    EngineRef m_car_engine;

public:
    Car() = default;                      // disabled default constructor
    Car(const Car &) = delete;            // disabled copy constructor
    Car &operator=(const Car &) = delete; // disabled copy assignment
    Car &operator=(Car &&) = delete;      // enabled move assignment
    Car(Car &&) = delete;                 // disabled move constructor
    ~Car() = default;

    Car(std::string m_car_reg_num,
        float m_price,
        EngineRef m_car_engine);

    std::string carRegNum() const { return m_car_reg_num; }

    float price() const { return m_price; }

    EngineRef carEngine() const { return m_car_engine; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
