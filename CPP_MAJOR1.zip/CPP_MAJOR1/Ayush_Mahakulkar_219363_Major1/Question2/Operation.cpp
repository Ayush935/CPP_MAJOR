#include "Operation.h"

Operation *Operation::_only_object{nullptr};

Operation *Operation::GetInstnce()
{
    if (_only_object)
    {
        return _only_object;
    }
    else
    {
        _only_object = new Operation();
        return _only_object;
    }
}

void Operation::CreateObjects(Container &m_data, EngineContainer &data1)
{

    data1.push_back(Engine("MH123", 125, 230, EngineType::CRDI));
    data1.push_back(Engine("MH124", 145, 250, EngineType::MPFI));
    data1.push_back(Engine("MH124", 325, 330, EngineType::MPFI));
    data1.push_back(Engine("MH125", 129, 130, EngineType::TURBOCHARGED));
    data1.push_back(Engine("MH126", 225, 430, EngineType::CRDI));

    m_data.emplace_back(std::make_shared<Car>("A12", 50000.0f, data1[0]));
    m_data.emplace_back(std::make_shared<Car>("A13", 150000.0f, data1[1]));
    m_data.emplace_back(std::make_shared<Car>("A14", 950000.0f, data1[2]));
    m_data.emplace_back(std::make_shared<Car>("A15", 850000.0f, data1[3]));
    m_data.emplace_back(std::make_shared<Car>("A16", 500000.0f, data1[4]));
}

bool Operation::AreAllInstancesHaveTorqueAbove120(Container &m_data)
{
    if (m_data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    return std::all_of(
        m_data.begin(),
        m_data.end(),
        [&](const CarPtr &ptr)
        {
            return ptr->carEngine().get().engineTorques() > 120;
        });
}

void Operation::AverageWhoseTHresoldValueisAbove(Container &m_data, float thresold)
{
    if (m_data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    int count{0};
    float sum = std::accumulate(
        m_data.begin(),
        m_data.end(),
        0.0f,
        [&](float value_upto_current_point, const CarPtr &ptr)
        {
            if (ptr->price() > thresold)
            {
                count++;
                return value_upto_current_point + ptr->price();
            }
            return value_upto_current_point;
        });

    std::cout << "AVerage whose thrsold is above given value " << sum / static_cast<float>(count) << std::endl;
}

void Operation::FindEngineType(Container &m_data, std::string reg_num)
{
    if (m_data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    auto itr = std::find_if(
        m_data.begin(),
        m_data.end(),
        [&](const CarPtr &ptr)
        {
            return ptr->carRegNum() == reg_num;
        });

    if (EngineType::CRDI == (*itr)->carEngine().get().type())
    {
        std::cout << "Engine Type is "
                  << "CRDI" << std::endl;
    }
    else if (EngineType::MPFI == (*itr)->carEngine().get().type())
    {
        std::cout << "Engine Type is "
                  << "MPFI" << std::endl;
    }
    else
    {
        std::cout << "Engine Type is "
                  << "TURBOCHARGED" << std::endl;
    }
}

EngineRef Operation::EngineTorqueHighest(Container &m_data)
{
    if (m_data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    auto itr = std::max_element(
        m_data.begin(),
        m_data.end(),
        [&](const CarPtr &ptr1, const CarPtr &ptr2)
        {
            return ptr1->carRegNum() < ptr2->carRegNum();
        });

    return (*itr)->carEngine().get();
}

std::optional<EngineContainer> Operation::ContainerOfEngineReference(Container &m_data)
{
    if (m_data.empty())
    {
        throw ContainerEmptyException("Data is empty", std::future_errc::no_state);
    }

    EngineContainer result;
    std::for_each(
        m_data.begin(),
        m_data.end(),
        [&](const CarPtr &ptr)
        {
            Engine p = ptr->carEngine().get();
            return result.push_back(p);
        });

    if (result.empty())
    {
        std::nullopt;
    }

    return result;
}
