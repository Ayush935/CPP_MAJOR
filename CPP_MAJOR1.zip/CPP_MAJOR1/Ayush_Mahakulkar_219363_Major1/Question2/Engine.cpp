#include "Engine.h"
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "m_engine_number: " << rhs.m_engine_number
       << " m_engine_torques: " << rhs.m_engine_torques
       << " m_horespower: " << rhs.m_horespower
       << " m_type: " << static_cast<int>(rhs.m_type);
    return os;
}

Engine::Engine(std::string m_engine_number, int m_engine_torques, int m_horespower, EngineType m_type)
    : m_engine_number{m_engine_number},m_horespower{m_horespower},m_type{m_type},m_engine_torques{m_engine_torques}
{
}