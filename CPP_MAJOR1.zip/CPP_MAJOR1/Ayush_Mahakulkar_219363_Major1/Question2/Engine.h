#ifndef ENGINE_H
#define ENGINE_H

#include <iostream>
#include "EngineType.h"

class Engine
{
private:
    /* data */
    std::string m_engine_number;
    int m_engine_torques;
    int m_horespower;
    EngineType m_type;

public:
    Engine() = default;                         // disabled default constructor
    Engine(const Engine &) = default;           // disabled copy constructor
    Engine &operator=(const Engine &) = default; // disabled copy assignment
    Engine &operator=(Engine &&) = delete;      // enabled move assignment
    Engine(Engine &&) = default;                 // disabled move constructor
    ~Engine() = default;

    Engine(std::string m_engine_number,
           int m_engine_torques,
           int m_horespower,
           EngineType m_type);

    std::string engineNumber() const { return m_engine_number; }

    int engineTorques() const { return m_engine_torques; }

    int horespower() const { return m_horespower; }

    EngineType type() const { return m_type; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);
};

#endif // ENGINE_H
