#include "Car.h"
std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "m_car_reg_num: " << rhs.m_car_reg_num
       << " m_price: " << rhs.m_price
       << " m_car_engine: " << rhs.m_car_engine.get();
    return os;
}

Car::Car(std::string m_car_reg_num, float m_price, EngineRef m_car_engine)
    : m_car_reg_num{m_car_reg_num},m_price{m_price},m_car_engine{m_car_engine}
{
}