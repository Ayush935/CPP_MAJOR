#include "Operation.h"
std::mutex m1;

int main(){
    Operation* ptr = Operation::GetInstnce();
    Container data;
    EngineContainer data1;
    ptr->CreateObjects(data,data1);
    
    
    std::future<std::optional<EngineContainer>> anser = std::async(&Operation::ContainerOfEngineReference,std::ref(data));
    std::future<bool> check = std::async(&Operation::AreAllInstancesHaveTorqueAbove120,std::ref(data));
    std::future<void> ans1 = std::async(&Operation::AverageWhoseTHresoldValueisAbove,std::ref(data),10000.0f);
    std::future<void> ans2 = std::async(&Operation::FindEngineType,std::ref(data),"A12");
    std::future<EngineRef> engRef = std::async(&Operation::EngineTorqueHighest,std::ref(data));
    

    
    try
    {
        /* code */
        std::cout<<"Engine Conatainers are"<<std::endl;
        std::optional<EngineContainer> answer = anser.get();
        if(answer.has_value()){
            EngineContainer res = answer.value();
            for(Engine ref: res){
                std::cout<<ref<<std::endl;
            }
        }

        bool ans = check.get();
        ans1.get();
        ans2.get();
        EngineRef ansRef = engRef.get();
        
        std::lock_guard<std::mutex>lk(m1);
        std::cout<<"All Engine Container Have Torque ABove 120 "<<std::boolalpha<<ans<<std::endl;
        
        std::cout<<"Same id with parameter"<<std::endl;
        std::cout<<"Engine with highest torque "<<ansRef.get()<<std::endl;

    }
    catch(ContainerEmptyException& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    
}