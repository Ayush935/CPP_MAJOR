#ifndef OPERATION_H
#define OPERATION_H

#include "Car.h"
#include <memory>
#include <optional>
#include <future>
#include <numeric>
#include <algorithm>
#include <mutex>
#include <vector>
#include "ContainerEmptyException.h"
using CarPtr = std::shared_ptr<Car>;
using Container = std::vector<CarPtr>;
using EngineRefContainer = std::vector<EngineRef>;
using EngineContainer = std::vector<Engine>;

class Operation
{
private:
  
   
    static Operation* _only_object;
    Operation(/* args */) = default;
    Operation(const Operation &) = delete;            // disabled copy constructor
    Operation &operator=(const Operation &) = delete; // disabled copy assignment
    Operation &operator=(Operation &&) = delete;      // enabled move assignment
    Operation(Operation &&) = delete; 
public:
    
    ~Operation() = default;
    static Operation* GetInstnce();

    void CreateObjects(Container& data,EngineContainer &data1);
    static std::optional<EngineContainer> ContainerOfEngineReference(Container& data);
    static bool AreAllInstancesHaveTorqueAbove120(Container& data);
    static void AverageWhoseTHresoldValueisAbove(Container& data,float thresold);
    static void FindEngineType(Container& data,std::string reg_num);
    static EngineRef EngineTorqueHighest(Container& data);

    

};

#endif // OPERATION_H
