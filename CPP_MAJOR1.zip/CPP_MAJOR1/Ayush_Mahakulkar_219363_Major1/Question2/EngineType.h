#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType
{
    CRDI,
    MPFI,
    TURBOCHARGED
};

#endif // ENGINETYPE_H
