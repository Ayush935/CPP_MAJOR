#include "Functionalities.h"

void CreateObjects(Container &data)
{
    data.emplace_back(std::make_shared<Vehicle>("MH123",12332.0F,VehicleCategoryType::PRIVATE,TransmissionType::AMT,23,true));
    data.emplace_back(std::make_shared<Vehicle>("MH124",14233.0F,VehicleCategoryType::GOVT,TransmissionType::AUTOMATIC,23,false));
    data.emplace_back(std::make_shared<Vehicle>("MH125",12533.0F,VehicleCategoryType::PUBLIC,TransmissionType::MANUAL,24,false));
    data.emplace_back(std::make_shared<Vehicle>("MH126",12353.0F,VehicleCategoryType::GOVT,TransmissionType::MANUAL,53,true));
    data.emplace_back(std::make_shared<Vehicle>("MH127",12336.0F,VehicleCategoryType::GOVT,TransmissionType::AMT,27,true));

}

ArrayContainer ArrayOfTransmissionType(Container &data, unsigned int N)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty",std::future_errc::no_state);
    }

    if(N<0||N>data.size()){
        throw;
    }

    std::array<TransmissionType,10> array;
    int count{0};
    auto itr = data.begin();
    std::advance(itr,data.size()-N);
    
    for(const VehiclePtr& ptr: data){
        array[count++] = ptr->transmissionType();
    }
    
    return array;
}

PriorityContainer PriorityWiseContainer(Container &data, std::function<bool(const VehiclePtr ptr1, const VehiclePtr ptr2)>fns)
{
     if(data.empty()){
        throw ContainerEmptyException("Data is empty",std::future_errc::no_state);
    }
    
    PriorityContainer result(data.begin(),data.end(),fns);

    return result;
    

}

SetContainer VehiclePrices(const Container &data)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty",std::future_errc::no_state);
    }

    SetContainer result;
    for(const VehiclePtr& ptr: data){
        result.insert(ptr->vehiclePrice());
    }

    if(result.empty()){
        throw;
    }

    return result;
}

MapContainer NKeyValuePlayers(const Container &data, unsigned int N)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty",std::future_errc::no_state);
    }
    
    MapContainer result;
    int count{0};
    for(const VehiclePtr& ptr: data){
        count++;
        result.emplace(std::make_pair<std::string,VehiclePtr>(ptr->vehicleId(),std::make_shared<Vehicle>(ptr)));
        if(count==N){
            break;
        }
    }
    
    if(result.empty()){
        throw;
    }

    return result;
}

ArrayContainer1 BootValuesWithGivenId(const Container &data, std::list<std::string>fs)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty",std::future_errc::no_state);
    }

    ArrayContainer1 result;
    int count{0};
    for(std::string val : fs){
       for(const VehiclePtr& ptr: data){
          if(val==ptr->vehicleId()){
            result[count++]=ptr->bootSpace();
          }
       }
    }

    if(result.empty()){
        throw;
    }

    return result;
    
}

Container HaveAllVehicleInsureTrue(const Container & data)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty",std::future_errc::no_state);
    }
    Container result;
    for(const VehiclePtr& ptr: data){
        if(ptr->isVehicleInsured()==true){
            result.push_back(ptr);
        }
    }

    if(result.empty()){
        throw;
    }

    return result;
}

Container BootSpace(const Container &data, std::function<bool(float,int)> fns)
{
    if(data.empty()){
        throw ContainerEmptyException("Data is empty",std::future_errc::no_state);
    }
    Container result;
    for(const VehiclePtr& ptr: data){
        if(fns(ptr->vehiclePrice(),ptr->bootSpace())){
             result.push_back(ptr);
        }
    }
    if(result.empty()){
        throw;
    }

    return result;

}
