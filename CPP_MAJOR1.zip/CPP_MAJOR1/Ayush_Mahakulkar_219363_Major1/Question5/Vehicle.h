#ifndef VEHICLE_H
#define VEHICLE_H

#include <iostream>
#include "VehicleCategoryType.h"
#include "TransmissionType.h"

class Vehicle
{
private:
    /* data */
    std::string m_vehicle_id;
    float m_vehicle_price;
    VehicleCategoryType m_vehicle_category;
    TransmissionType m_transmission_type;
    int m_boot_space;
    bool m_is_vehicle_insured;

public:
    Vehicle() = default;                          // disabled default constructor
    Vehicle(const Vehicle &) = delete;            // disabled copy constructor
    Vehicle &operator=(const Vehicle &) = delete; // disabled copy assignment
    Vehicle &operator=(Vehicle &&) = default;     // enabled move assignment
    Vehicle(Vehicle &&) = delete;                 // disabled move constructor
    ~Vehicle() = default;

    Vehicle(std::string m_vehicle_id,
            float m_vehicle_price,
            VehicleCategoryType m_vehicle_category,
            TransmissionType m_transmission_type,
            int m_boot_space,
            bool m_is_vehicle_insured);

    std::string vehicleId() const { return m_vehicle_id; }

    float vehiclePrice() const { return m_vehicle_price; }

    VehicleCategoryType vehicleCategory() const { return m_vehicle_category; }

    TransmissionType transmissionType() const { return m_transmission_type; }

    int bootSpace() const { return m_boot_space; }

    bool isVehicleInsured() const { return m_is_vehicle_insured; }

    friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);

    
};

#endif // VEHICLE_H
