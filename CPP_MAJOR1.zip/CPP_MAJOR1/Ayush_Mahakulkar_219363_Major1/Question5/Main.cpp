#include "Functionalities.h"

int main(){
    Container data;
    CreateObjects(data);
    std::list<std::string> l1{"MH123","MH124"};
    std::future<ArrayContainer> result = std::async(&ArrayOfTransmissionType,std::ref(data),2);
    std::future<ArrayContainer1> result1 = std::async(&BootValuesWithGivenId,std::ref(data),std::ref(l1));
    std::future<SetContainer> result2 = std::async(&VehiclePrices,std::ref(data));
    std::future<Container> result3 = std::async(&HaveAllVehicleInsureTrue,std::ref(data));
    std::future<Container> result4 = std::async(&BootSpace,std::ref(data),[](float num,int num2){return num>20.0f&&num2>50;});
    std::future<MapContainer> result5 = std::async(&NKeyValuePlayers,std::ref(data),2);
    std::future<PriorityContainer> result6 = std::async(&PriorityWiseContainer,std::ref(data),[](const VehiclePtr ptr1, const VehiclePtr ptr2){return ptr1->vehiclePrice()<ptr2->vehiclePrice();});
    try
    {
        /* code */
        ArrayContainer res = result.get();
        ArrayContainer1 re1 = result1.get();
        SetContainer res2 = result2.get();
        Container res3 = result3.get();
        Container res4 = result4.get();
        MapContainer res5 = result5.get();
        PriorityContainer res6 = result6.get();

        std::cout<<"Array Container Containnig TransmissionType ";
        for(int i=0;i<2;i++){
            std::cout<<static_cast<int>(res[i])<<" ";
        }
        std::cout<<std::endl;

        std::cout<<"Array Container Containnig BootValue matching same id";
        for(int i=0;i<2;i++){
            std::cout<<re1[i]<<" ";
        }
        std::cout<<std::endl;

        std::cout<<"Set Container Having Vehicle Prices "<<" ";
        for(float a: res2){
            std::cout<<a<<" ";
        }
        std::cout<<std::endl;

        std::cout<<"Instances Having vehicle insured true "<<"\n";
        for(VehiclePtr &ptr: res3){
            std::cout<<*ptr<<std::endl;
        }
         std::cout<<std::endl;

        std::cout<<"Instances Having accepted predicate "<<"\n";
        for(VehiclePtr &ptr: res4){
            std::cout<<*ptr<<std::endl;
        }
         std::cout<<std::endl;

       

    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
}