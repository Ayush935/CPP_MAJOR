#ifndef VEHICLECATEGORYTYPE_H
#define VEHICLECATEGORYTYPE_H

enum class VehicleCategoryType{
   PUBLIC,
   PRIVATE,
   GOVT
};

#endif // VEHICLECATEGORYTYPE_H
