#ifndef TRANSMISSIONTYPE_H
#define TRANSMISSIONTYPE_H

enum class TransmissionType{
    AMT,
    MANUAL,
    AUTOMATIC
};

#endif // TRANSMISSIONTYPE_H
