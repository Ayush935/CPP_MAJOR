#include "Vehicle.h"
std::ostream &operator<<(std::ostream &os, const Vehicle &rhs) {
    os << "m_vehicle_id: " << rhs.m_vehicle_id
       << " m_vehicle_price: " << rhs.m_vehicle_price
       << " m_vehicle_category: " << static_cast<int>(rhs.m_vehicle_category)
       << " m_transmission_type: " << static_cast<int>(rhs.m_transmission_type)
       << " m_boot_space: " << rhs.m_boot_space
       << " m_is_vehicle_insured: " << rhs.m_is_vehicle_insured;
    return os;
}

Vehicle::Vehicle(std::string m_vehicle_id, float m_vehicle_price, VehicleCategoryType m_vehicle_category, TransmissionType m_transmission_type, int m_boot_space, bool m_is_vehicle_insured)
    : m_vehicle_id{m_vehicle_id},m_vehicle_price{m_vehicle_price},m_vehicle_category{m_vehicle_category},m_transmission_type{m_transmission_type},m_boot_space{m_boot_space},m_is_vehicle_insured{m_is_vehicle_insured}
{
}