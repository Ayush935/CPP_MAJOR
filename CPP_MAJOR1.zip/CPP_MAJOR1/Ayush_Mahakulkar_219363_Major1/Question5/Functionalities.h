#include "Vehicle.h"
#include <vector>
#include <memory>
#include <array>
#include <list>
#include <queue>
#include <functional>
#include <unordered_set>
#include <unordered_map>
#include "ContainerEmptyDataException.h"
using VehiclePtr = std::shared_ptr<Vehicle>;
using ArrayContainer = std::array<TransmissionType,10>;
using ArrayContainer1 = std::array<float,10>;
using Container = std::vector<VehiclePtr>;
using PriorityContainer = std::priority_queue<Vehicle,Container,std::function<bool(const VehiclePtr ptr1, const VehiclePtr ptr2)>>;
using SetContainer = std::unordered_set<float>;
using MapContainer = std::unordered_map<std::string,VehiclePtr>;
using MapEntry = std::pair<std::string,VehiclePtr>;
void CreateObjects(Container& data);

ArrayContainer ArrayOfTransmissionType(Container& data,unsigned int N);

PriorityContainer PriorityWiseContainer(Container&data,std::function<bool(const VehiclePtr ptr1, const VehiclePtr ptr2)>);

SetContainer VehiclePrices(const Container& data);

MapContainer NKeyValuePlayers(const Container& data,unsigned int N);

ArrayContainer1 BootValuesWithGivenId(const Container& data,std::list<std::string>);

Container BootSpace(const Container& data,std::function<bool(float,int)>);

Container HaveAllVehicleInsureTrue(const Container& data);


